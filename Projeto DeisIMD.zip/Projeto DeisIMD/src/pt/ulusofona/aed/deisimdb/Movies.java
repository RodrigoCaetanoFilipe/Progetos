package pt.ulusofona.aed.deisimdb;

import static pt.ulusofona.aed.deisimdb.Main.actors;

public class Movies {
    int id;
    String name;
    float duration;
    int budget;
    String releaseDate;



    public Movies(int id, String name, float duration, int budget, String releaseDate) {
        this.id = id;
        this.name = name;
        this.duration = duration;
        this.budget = budget;

        String[] data = releaseDate.split("-");
        this.releaseDate = data[2] + "-" + data[1] + "-" + data[0];

    }
    @Override
    public String toString() {
        //com budget e horas de filme
        //String texto = id + " | " + name + " | " + duration + " | " + budget + " | " + releaseDate;
        String texto = id + " | " + name + " | " + releaseDate;
        return texto;

    }
}
