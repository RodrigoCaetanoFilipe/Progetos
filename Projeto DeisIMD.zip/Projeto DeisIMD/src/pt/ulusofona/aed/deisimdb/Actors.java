package pt.ulusofona.aed.deisimdb;

import java.util.Objects;

public class Actors {
    int id;
    String name;
    String gender;
    int movieId;
    public Actors(int id, String name, String gender, int movieId){
        this.id = id;
        this.name = name;

        if (Objects.equals(gender, "M")){
            this.gender = "Masculino";
        }else if(Objects.equals(gender, "F")){
            this.gender = "Feminino";
        }
        this.movieId = movieId;
    }
    @Override
    public String toString() {
        String texto = id + " | " + name + " | " + gender + " | " + movieId;

        return texto;
    }
}
