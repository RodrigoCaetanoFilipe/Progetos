import java.io.File
import java.io.Serializable

const val letras = "0ABCDEFGHIJKLMNOPQRSTUVWXYZ"
val caracterHumano = "\u001b[31mϙ\u001b[0m"
val caracterComputador = "\u001b[34mϙ\u001b[0m"

fun criaTabuleiroVazio(numLinhas: Int?,numColunas: Int?): Array<Array<String?>>{
    val tabuleiroVazio:Array<Array<String?>> = Array(numLinhas!!) { Array(numColunas!!) { null } }
    return tabuleiroVazio
}
fun validaTabuleiro(numLinhas:Int?, numColunas:Int?): Boolean{
    return if(numLinhas != null && numColunas != null){
        (numLinhas == 5 && numColunas == 6) || (numLinhas == 6 && numColunas == 7)||(numLinhas == 7 && numColunas == 8)
    }else false

}
fun processaColuna(numColunas: Int,coluna:String?): Int?{
    val letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    if (coluna == null || coluna.length != 1) {
        return null
    }else{
        var posicao=0
        val colunaToChar = coluna[0]
        var encontrado:Int? = null
        while (encontrado == null && posicao < numColunas){
            if (letras[posicao] == colunaToChar){
                encontrado = posicao
            }else{
                posicao++
            }
        }
        return encontrado
    }
}
fun nomeValido(nome: String): Boolean{
    if (nome.length in 4..11){
        for (element in nome){
            if (element == ' '){
                return false
            }
        }
        return true
    }else{
        return false
    }
}
fun criaTopoTabuleiro(numColunas: Int?): String{
    var topo = "╔"
    for (i in 1..<numColunas!!){
        topo = "$topo════"
    }
    topo = "$topo═══╗"
    return topo
}
fun criaMeioTabuleiro(numLinhas: Int?,numColunas: Int?,tabuleiroArray:Array<Array<String?>>): String{
    var linha = 0
    var textoFinal = ""
    while (linha < numLinhas!!) {
        var texto = "║"
        var coluna = 0
        while (coluna < numColunas!!) {
            texto += if (coluna < numColunas - 1) {
                " " + (tabuleiroArray[linha][coluna] ?: " ") + " |"
            } else {
                " " + (tabuleiroArray[linha][coluna] ?: " ") + " ║"
            }
            coluna += 1
        }
        textoFinal += if(linha < numLinhas -1){
            "$texto\n"
        }else{
            texto
        }
        linha += 1
    }
    return textoFinal
}
fun criaLegendaHorizontal(numColunas: Int?): String{
    val letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    var legenda = "  "
    var coluna = 0
    while (coluna < numColunas!!-1){
        val letra = letras[coluna]
        legenda += "$letra | "
        coluna += 1
    }
    legenda += letras[coluna] + "  "
    return  legenda
}
fun criaTabuleiro(tabuleiroArray:Array<Array<String?>>, mostraLegenda:Boolean= true): String {
    val numColunas = tabuleiroArray[0].size
    val numLinhas = tabuleiroArray.size
    val topo = criaTopoTabuleiro(numColunas)
    val meio = criaMeioTabuleiro(numLinhas, numColunas, tabuleiroArray)
    val legenda = criaLegendaHorizontal(numColunas)

    var tabuleiro = ("$topo\n" + meio)
    if (mostraLegenda) {
        tabuleiro += "\n" + legenda
    }

    return tabuleiro
}

fun contaBaloesLinha(tabuleiro:Array<Array<String?>>,linha:Int):Int{
    val colunas = tabuleiro[0].size
    var nBaloes = 0
    var coluna = 0
    while (coluna < colunas){
        if (tabuleiro[linha][coluna] != null){
            nBaloes++
        }
        coluna++
    }
    return nBaloes
}
fun contaBaloesColuna(tabuleiro:Array<Array<String?>>,coluna:Int):Int{
    val linhas = tabuleiro.size
    var nBaloes = 0
    var linha = 0
    while (linha < linhas){
        if (tabuleiro[linha][coluna] != null){
            nBaloes++
        }else{
            return nBaloes
        }
        linha++
    }
    return nBaloes
}
fun colocaBalao(tabuleiro:Array<Array<String?>>,coluna:Int,humano:Boolean): Boolean{
    val nBaloes = contaBaloesColuna(tabuleiro, coluna)
    if (nBaloes < tabuleiro.size) {
        val balao = if (humano) caracterHumano else caracterComputador
        tabuleiro[nBaloes][coluna] = balao
        return true
    }
    return false
}

fun jogadaNormalComputador(tabuleiro:Array<Array<String?>>): Int{
    val nColunas = tabuleiro[0].size
    val nLinhas = tabuleiro.size
    var escolha = 0
    var linha=0
    while (linha < nLinhas){
        var coluna=0
        if (contaBaloesLinha(tabuleiro,linha) < nColunas){
            while (coluna < nColunas){
                if (tabuleiro[linha][coluna] == null){
                    escolha = coluna
                    return escolha
                }
                coluna++
            }
        }
        linha++
        escolha = coluna
    }
    return escolha
}
fun eVitoriaHorizontal(tabuleiro:Array<Array<String?>>): Boolean{
    val nColunas = tabuleiro[0].size
    val nLinhas = tabuleiro.size

    var linha=0
    while (linha < nLinhas){
        var coluna=0
        var jogador = 0
        var computador = 0

        if (contaBaloesLinha(tabuleiro,linha) >= 4){
            while (coluna < nColunas){
                if (tabuleiro[linha][coluna] == caracterHumano){
                    jogador++
                }else {
                    jogador = 0
                }
                if (tabuleiro[linha][coluna] == caracterComputador){
                    computador++
                }else{
                    computador = 0
                }
                if ((jogador == 4 || computador == 4)){
                    return true
                }
                coluna++
            }
        }
        linha++
    }
    return false
}
fun eVitoriaVertical(tabuleiro:Array<Array<String?>>): Boolean{
    val nColunas = tabuleiro[0].size
    val nLinhas = tabuleiro.size
    var coluna=0
    while (coluna < nColunas){
        var linha=0
        var jogador = 0
        var computador = 0
        if (contaBaloesColuna(tabuleiro,coluna) >= 4){
            while (linha < nLinhas){
                if (tabuleiro[linha][coluna] == caracterHumano){
                    jogador++
                }else if (tabuleiro[linha][coluna] == caracterComputador){
                    computador++
                }else{
                    jogador = 0
                    computador = 0
                }
                if ((jogador == 4 || computador == 4)){
                    return true
                }
                linha++
            }
        }
        coluna++
    }
    return false
}
fun eVitoriaDiagonal(tabuleiro:Array<Array<String?>>): Boolean{
    return false
}
fun ganhouJogo(tabuleiro:Array<Array<String?>>): Boolean{
    val vitoriaHorizontal = eVitoriaHorizontal(tabuleiro)
    val vitoriaVertical = eVitoriaVertical(tabuleiro)
    val vitoriaDiagonal = eVitoriaDiagonal(tabuleiro)

    return vitoriaHorizontal || vitoriaVertical || vitoriaDiagonal

}
fun eEmpate(tabuleiro:Array<Array<String?>>): Boolean{
    val nColunas = tabuleiro[0].size
    val nLinhas = tabuleiro.size
    var coluna=0
    while (coluna != nColunas){
        if(contaBaloesColuna(tabuleiro,coluna) != nLinhas){
            return false
        }
        coluna++
    }
    return true
}
fun explodeBalao(tabuleiro:Array<Array<String?>>,coordenadas:Pair<Int, Int>): Boolean{
    //facultativo
    return false
}
fun jogadaExplodirComputador(tabuleiro:Array<Array<String?>>):Pair<Int, Int>{
    //facultativo
    return Pair(0,2)
}
fun leJogo(ficheiro:String):Pair<String, Array<Array<String?>>> {
    var arrayAToa = arrayOf(arrayOf(null,"E"))
    return Pair("Teste",arrayAToa)
}
fun gravaJogo(ficheiro:String, tabuleiro: Array<Array<String?>>, nome: String){
    val filePrinter = File(ficheiro).printWriter()
    filePrinter.println(nome)
}

fun eQuaseVitoriaHorizontal(tabuleiro: Array<Array<String?>>, linha: Int, colunaInicial: Int): Int?{
    val colunasMax = tabuleiro[0].size
    val linhasMax = tabuleiro.size
    if (colunaInicial >= colunasMax || linha >= linhasMax){
        return null
    }
    val posicaoInicial = tabuleiro[linha][colunaInicial]

    if (tabuleiro[linha][colunaInicial] == null) {
        return null
    }

    if (colunaInicial + 3 < colunasMax) {
        if (tabuleiro[linha][colunaInicial] == tabuleiro[linha][colunaInicial + 1] &&
            tabuleiro[linha][colunaInicial] == tabuleiro[linha][colunaInicial + 2]) {

            if (tabuleiro[linha][colunaInicial + 3] == null) {
                return colunaInicial + 3
            }
        }
    }

    return null
}
fun eQuaseVitoriaVertical(tabuleiro: Array<Array<String?>>, linhaInicial: Int, coluna: Int): Boolean{
    val linhasMax = tabuleiro.size
    val colunasMax = tabuleiro[0].size
    if (linhaInicial >= linhasMax || coluna >= colunasMax){
        return false
    }
    val posicaoInicial = tabuleiro[linhaInicial][coluna]

    if (tabuleiro[linhaInicial][coluna] == null) {
        return false
    }

    if (linhaInicial + 3 < linhasMax) {
        if (tabuleiro[linhaInicial][coluna] == tabuleiro[linhaInicial + 1][coluna] &&
            tabuleiro[linhaInicial][coluna] == tabuleiro[linhaInicial + 2][coluna]) {

            if (tabuleiro[linhaInicial + 3][coluna] == null) {
                return true
            }
        }
    }

    return false

}
fun calculaEstatisticas(tabuleiro: Array<Array<String?>>): Array<Int>{
    val estatistica:Array<Int> = Array(4){0}
    val nColunas = tabuleiro[0].size
    val nLinhas = tabuleiro.size
    var jogador = 0
    var computador = 0
    var coluna=0
    var quaseVitVertical = 0
    var quaseVitHorizontal = 0

    while (coluna < nColunas){
        var linha=0
        while (linha < nLinhas){
            if (tabuleiro[linha][coluna] == caracterHumano){
                jogador++
            }else if (tabuleiro[linha][coluna] == caracterComputador){
                computador++
            }
            linha++
        }
        coluna++
    }
    coluna= 0
    while (coluna < nColunas) {
        if (eQuaseVitoriaVertical(tabuleiro, 0, coluna)) {
            quaseVitVertical++
        }
        coluna++
    }
    var linha = 0
        while ( linha < nLinhas) {
        if (eQuaseVitoriaHorizontal(tabuleiro, linha, 0) != null) {
            quaseVitHorizontal++
        }
            linha++
    }
    estatistica[0]= jogador + computador
    estatistica[1]= computador
    estatistica[2]= jogador
    estatistica[3]= quaseVitVertical + quaseVitHorizontal
    return estatistica
}
fun sugestaoJogadaNormalHumano(tabuleiro: Array<Array<String?>>): Int?{
    val nColunas = tabuleiro[0].size
    val nLinhas = tabuleiro.size
    var coluna = 0
    while (coluna < nColunas){
        if(eQuaseVitoriaVertical(tabuleiro,0,coluna)){
            return coluna
        }
        coluna++
    }
    var linha = 0
    while (linha < nLinhas){
        if(eQuaseVitoriaHorizontal(tabuleiro,linha,0) != null){
            return eQuaseVitoriaHorizontal(tabuleiro,linha,0)
        }
        linha++
    }
    return null
}
fun novoJogo():Array<Serializable?>{
    var linhas: Int? = null
    var colunas: Int? = null
    var tabuleiro:Array<Array<String?>> = arrayOf(arrayOf(null))
    var nome = "E"

    //validações
    var tabuleiroValido = false
    var validadeNome = false
    while (!tabuleiroValido) {
        while (linhas == null) {
            println("Numero de linhas:")
            val verificaLinhas = readln().toIntOrNull()
            when {
                verificaLinhas == null -> println("Numero Invalido")
                (verificaLinhas > 0) -> linhas = verificaLinhas
                else -> println("Numero invalido")
            }
        }
        while (colunas == null) {
            println("Numero de colunas:")
            val verificaColunas = readln().toIntOrNull()
            when {
                verificaColunas == null -> println("Numero Invalido")
                (verificaColunas > 0) -> colunas = verificaColunas
                else -> println("Numero invalido")
            }
        }
        when (validaTabuleiro(linhas, colunas)) {
            true -> {
                tabuleiro = criaTabuleiroVazio(linhas, colunas)
                tabuleiroValido = true
            }false -> {
                linhas = null
                colunas = null
                println("Tamanho do tabuleiro invalido")
            }
        }
    }
    while (!validadeNome) {
        println("Nome do jogador 1:")
        nome = readln()
        when (nomeValido(nome)) {
            true -> {
                validadeNome = true
            }
            false -> {
                println("Nome de jogador invalido")
                nome = ""
            }
        }
    }
    println(criaTabuleiro(tabuleiro))

    val jogoArray = arrayOf(linhas,colunas,tabuleiro,nome)
    return  jogoArray
}
fun gravarJogoMenu(save:Boolean, tabuleiro: Array<Array<String?>>, nome: String,linhas: Int,colunas: Int){
    if(save){
        println("Introduza o nome do ficheiro (ex: jogo.txt)")
        val ficheiro = readln()
        gravaJogo(ficheiro, tabuleiro, nome)
        val confirmacao = "Tabuleiro " + linhas + "x$colunas" + " gravado com sucesso"
        println(confirmacao)
    }else{
        println("Funcionalidade Gravar nao esta disponivel")
    }
}
fun main() {
    var save = false
    var tabuleiro:Array<Array<String?>> = arrayOf(arrayOf(null))
    var nome:String? = null
    println()
    println("Bem-vindo ao jogo \"4 Baloes em Linha\"!")
    var linhas: Int? = null
    var colunas: Int? = null
    var jogo = true
    while(jogo) {
        var opcaoValida = false
        while (!opcaoValida){
        println()
        println("1. Novo Jogo")
        println("2. Gravar Jogo")
        println("3. Ler Jogo")
        println("0. Sair")
        println()
        while (!opcaoValida){
        val opcao = readln().toIntOrNull()
        when(opcao) {
            1 -> {
                opcaoValida = true
                val novoJogo = novoJogo()
                linhas = novoJogo[0] as Int?
                colunas = novoJogo[1] as Int?
                tabuleiro = novoJogo[2] as Array<Array<String?>>
                nome = novoJogo[3].toString()
                save = true
            }
            2 -> {
                gravarJogoMenu(save,tabuleiro,nome!!,linhas!!,colunas!!)
            }
            3 -> {
                opcaoValida = true
                println("Introduza o nome do ficheiro (ex: jogo.txt)")
                val nomeFicheiro = readln()
                nome = leJogo(nomeFicheiro).first
                tabuleiro = leJogo(nomeFicheiro).second
                println("Tabuleiro 6x7 lido com sucesso!")
            }
            0 -> {
                print("A sair...")
                opcaoValida = true
                jogo = false
            }
            else -> {
                println("Opcao invalida. Por favor, tente novamente.")
            }
        }
        }
            if(jogo){
            var partida =true
            while (partida) {
                println("\n$nome: $caracterHumano\nTabuleiro ${linhas}X$colunas")
                val opcoesLetras = "(A..${letras[colunas!!]})"

                var selecaoValida = false
                while (!selecaoValida) {
                    println("Coluna? $opcoesLetras:")
                    when (val selecao = readln()) {
                        "Sair" -> {
                            selecaoValida = true
                            partida = false
                        }
                        "?" -> println(
                            sugestaoJogadaNormalHumano(tabuleiro)?.let {
                                "Sugestao de jogada na coluna: ${letras[it + 1]}"
                            } ?: "Nao existe uma sugestao de jogada"
                        )
                        "Gravar" -> gravarJogoMenu(save, tabuleiro, nome!!, linhas!!, colunas)
                        else -> when (val coluna = processaColuna(colunas, selecao)) {
                            null -> println("Coluna invalida")
                            else -> when (colocaBalao(tabuleiro, coluna, true)) {
                                true -> {
                                    println("Coluna escolhida: $selecao")
                                    selecaoValida = true
                                }
                                else -> println("Coluna invalida")
                            }
                        }
                    }
                }
                if (partida) {
                    println(criaTabuleiro(tabuleiro))
                    when {
                        ganhouJogo(tabuleiro) -> {
                            println("Parabens $nome! Ganhou!")
                            partida = false
                        }
                        eEmpate(tabuleiro) -> {
                            println("Foi empate")
                            partida = false
                        }
                    }
                }

                if (partida) {
                    println("\nComputador: $caracterComputador\nTabuleiro ${linhas}X$colunas")
                    val jogadaRobot = jogadaNormalComputador(tabuleiro)
                    println("Coluna escolhida: ${letras[jogadaRobot + 1]}")
                    colocaBalao(tabuleiro, jogadaRobot, false)
                    println(criaTabuleiro(tabuleiro))

                    when {
                        ganhouJogo(tabuleiro) -> {
                            println("Perdeu! Ganhou o Computador.")
                            partida = false
                        }
                        eEmpate(tabuleiro) -> {
                            println("Foi empate")
                            partida = false
                        }
                    }
                }
            }
            }
        }
    }
}