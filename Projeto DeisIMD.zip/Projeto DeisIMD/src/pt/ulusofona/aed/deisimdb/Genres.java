package pt.ulusofona.aed.deisimdb;

public class Genres {
    int id;
    String name;
    public Genres(int id, String name){
        this.id = id;
        this.name = name;
    }
    @Override
    public String toString() {
        String texto = id + " | " + name;
        return texto;
    }
}
