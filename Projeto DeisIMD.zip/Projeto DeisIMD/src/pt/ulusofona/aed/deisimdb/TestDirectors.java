package pt.ulusofona.aed.deisimdb;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestDirectors {

    @Test
    public void testToStringDirectors() {
        Directors director = new Directors(1, "Rodrigo Filipe", 1000);
        String expected = "1 | Rodrigo Filipe | 1000";
        assertEquals(expected, director.toString());
    }

    @Test
    public void testToStringDirectors_2() {
        Directors director = new Directors(2, "Jony Spiner", 1500);
        String expected = "2 | Jony Spiner | 1500";
        assertEquals(expected, director.toString());
    }

    @Test
    public void testToStringDirectors_3() {
        Directors director = new Directors(3, "MadStar", 2000);
        String expected = "3 | MadStar | 2000";
        assertEquals(expected, director.toString());
    }

    @Test
    public void testToStringDirectors_4() {
        Directors director = new Directors(4, "", 2500);
        String expected = "4 |  | 2500";
        assertEquals(expected, director.toString());
    }

    @Test
    public void testToStringDirectors_5() {
        Directors director = new Directors(5, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 3000);
        String expected = "5 | AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA | 3000";
        assertEquals(expected, director.toString());
    }
}