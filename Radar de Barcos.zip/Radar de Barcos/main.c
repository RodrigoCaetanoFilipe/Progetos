#include <stdio.h>
#include <ctype.h>

//Estrutura do barco (Guarda Id, linha e coluna)
struct Barco {
    char id;
    int linha;
    int coluna;
};

//Função para ler o ficheiro e insere-o numa matriz
void lerTabelaDeFicheiro(char tabela[20][80], const char *nomeFicheiro) {
    FILE *ficheiro = fopen(nomeFicheiro, "r");

    //Caso não consiga abrir o ficheiro dá este erro
    if (ficheiro == NULL) {
        printf("Erro ao abrir o ficheiro %s\n", nomeFicheiro);
        return;
    }

    //converte o caracter do ficheiro para um caracter aqui no main e coloca na matriz
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 80; j++) {
            char c = fgetc(ficheiro);

            //muda de linha caso n haja mais nada no ficheiro
            if (c == '\n') {
                c = fgetc(ficheiro);
            }

            tabela[i][j] = c;
        }
    }

    //fecha o ficheiro PARA NÃO OCUPAR ESPAÇO
    fclose(ficheiro);
}

//consulta a localização dos barcos
void consultarCoordenadas(char tabela[20][80], struct Barco *barco) {
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 80; j++) {
            if (tabela[i][j] == barco->id) {
                //guarda as coordenadas do barco no struct
                barco->linha = i + 1;
                barco->coluna = j + 1;
                printf("O barco %c encontra-se na linha %d e na coluna %d\n", barco->id, barco->linha, barco->coluna);
                return; // Encontrou o Barco :)
            }
        }
    }
    // O BARCO N EXISTE (O BARCO EXPLODIU)
    printf("Barco %c nao encontrado.\n", barco->id);
}




//Compara a posição dos barcos entre as duas tabelas e imprime o movimento (acho que é um pouco obvio)
void listarMovimentos(char tabelaAntes[20][80], char tabelaDepois[20][80]) {
    //inicializa os barcos com todos os parâmetros a 0.
    struct Barco barco_1 = {0};
    struct Barco barco_2 = {0};

    printf("Escolha qual o barco que quer listar o movimento: \n");
    scanf(" %c", &barco_1.id);//escolhe o barco que quer verificar o movimento.
    barco_1.id = (char)toupper(barco_1.id);
    barco_2.id = barco_1.id;


    // Verifica se o barco existe em AMBAS as tabelas
    int encontradoAntes = 0;
    int encontradoDepois = 0;

    // procura na tabelaAntes
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 80; j++) {
            if (tabelaAntes[i][j] == barco_1.id) {
                barco_1.linha = i + 1;
                barco_1.coluna = j + 1;
                encontradoAntes = 1;
                break;
            }
        }
        //se encontrou fecha a função
        if (encontradoAntes) break;
    }

    // procura na tabelaDepois
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 80; j++) {
            if (tabelaDepois[i][j] == barco_2.id) {
                barco_2.linha = i + 1;
                barco_2.coluna = j + 1;
                encontradoDepois = 1;
                break;
            }
        }
        //se encontrou fecha a função.
        if (encontradoDepois) break;
    }

    // Trata dos casos onde o barco não foi encontrado
    if (!encontradoAntes || !encontradoDepois) {
        printf("Barco %c não encontrado em uma das tabelas.\n", barco_1.id);
        return;
    }

    // Determina o tipo de movimento
    printf("Movimento: ");
    if (barco_1.linha == barco_2.linha && barco_1.coluna == barco_2.coluna) {
        printf("O barco não se moveu.\n");
    }
    else if (barco_1.linha < barco_2.linha && barco_1.coluna == barco_2.coluna) {
        printf("O barco moveu-se para baixo.\n");
    }
    else if (barco_1.linha > barco_2.linha && barco_1.coluna == barco_2.coluna) {
        printf("O barco moveu-se para cima.\n");
    }
    else if (barco_1.linha == barco_2.linha && barco_1.coluna < barco_2.coluna) {
        printf("O barco moveu-se para a direita.\n");
    }
    else if (barco_1.linha == barco_2.linha && barco_1.coluna > barco_2.coluna) {
        printf("O barco moveu-se para a esquerda.\n");
    }
    else {
        printf("O barco moveu-se na diagonal.\n");
    }
}

//função para imprimir a tabela, pega o caracter c da função anterior e imprime
void imprimirTabela(char tabela[20][80]) {
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 80; j++) {
            printf("%c", tabela[i][j]);
        }
        printf("\n");//quando acaba o numero de colunas muda de linha
    }
}

//função main
int main() {
    //inicia as tabelas
    char tabelaAntes[20][80];
    char tabelaDepois[20][80];

    //Lê os ficheiros
    lerTabelaDeFicheiro(tabelaAntes, "tabela_antes.txt");
    lerTabelaDeFicheiro(tabelaDepois, "tabela_depois.txt");

    //Menu
    char opcao;

    //inicio do loop
    do {
        printf("\nMenu:\n");
        printf("1 - Imprimir tabela \"antes\"\n");
        printf("2 - Imprimir tabela \"depois\"\n");
        printf("3 - Consultar as coordenadas de um barco\n");
        printf("4 - Listar barcos que se moveram\n");
        printf("5 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf(" %c", &opcao);

        switch (opcao) {
            case '1':
                printf("\nTabela Antes:\n");
                imprimirTabela(tabelaAntes);
                break;

            case '2':
                printf("\nTabela Depois:\n");
                imprimirTabela(tabelaDepois);
                break;

            case '3':
                //inicio de consultar coordenadas
                printf("Qual a tabela que quer consultar? Tabela antes - 1 Tabela depois - 2\n");

            char barco_escolhido;
            char tabela_escolhida;

            scanf(" %c", &tabela_escolhida);
            if (tabela_escolhida != '1' && tabela_escolhida != '2') {
                printf("Opcao invalida! Digite 1 ou 2.\n");
                break;
            }

            printf("Escolha o barco que quer encontrar: \n");
            scanf(" %c", &barco_escolhido);
            barco_escolhido = (char)toupper(barco_escolhido);

            if (barco_escolhido < 'A' || barco_escolhido > 'E') {
                printf("O barco %c nao existe.\n", barco_escolhido);
                break;
            }

            struct Barco barco;
            barco.id = barco_escolhido;

            if (tabela_escolhida == '1') {
                consultarCoordenadas(tabelaAntes, &barco);
            } else if (tabela_escolhida == '2') {
                consultarCoordenadas(tabelaDepois, &barco);
            } else {
                printf("Opcao invalida!\n");
            }
            break;
            //Fim de consultar coordenadas

            case '4':
                listarMovimentos(tabelaAntes, tabelaDepois);
                break;

            case '5':
                //sair do programa
                printf("A sair do programa...\n");
                break;

            default:
                //Imputs invalidos
                printf("Opcao invalida!\n");
        }
    } while (opcao != '5');
    //fim do loop

    return 0;
}