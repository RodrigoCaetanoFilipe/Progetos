package pt.ulusofona.aed.deisimdb;

public class InputInvalido {
    String ficheiro;
    int linhasValidas;
    int linhasInvalidas;
    int primeiroErro;
    public InputInvalido(String ficheiro, int linhasValidas, int linhasInvalidas, int primeiroErro ){
        this.ficheiro = ficheiro;
        this.linhasValidas = linhasValidas;
        this.linhasInvalidas = linhasInvalidas;
        this.primeiroErro = primeiroErro;
    }
    //Nome dos ficheiros
    //"movies.csv", "actors.csv", "directors.csv", "genres.csv"
    //            , "genre_movies.csv", "movie_votes.csv"
    @Override
    public String toString() {
        String texto = ficheiro + " | " + linhasValidas + " | " + linhasInvalidas + " | " + primeiroErro;
        return texto;
    }
}
