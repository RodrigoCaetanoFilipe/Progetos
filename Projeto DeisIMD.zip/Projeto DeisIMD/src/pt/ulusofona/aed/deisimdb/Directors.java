package pt.ulusofona.aed.deisimdb;

public class Directors {
    int id;
    String name;
    int movieId;
    public Directors(int id, String name, int movieId){
        this.id = id;
        this.name = name;
        this.movieId = movieId;
    }

    @Override
    public String toString() {
        String texto = id + " | " + name + " | " + movieId;
        return texto;
    }
}
