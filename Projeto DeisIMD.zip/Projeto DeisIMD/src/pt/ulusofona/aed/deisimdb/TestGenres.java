package pt.ulusofona.aed.deisimdb;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestGenres {

    @Test
    public void testToStringGenres() {
        Genres genre = new Genres(1, "Karaté Alentejano");
        String expected = "1 | Karaté Alentejano";
        assertEquals(expected, genre.toString());
    }

    @Test
    public void testToStringGenres_2() {
        Genres genre = new Genres(2, "A");
        String expected = "2 | A";
        assertEquals(expected, genre.toString());
    }

    @Test
    public void testToStringGenres_3() {
        Genres genre = new Genres(3, "Big Brother");
        String expected = "3 | Big Brother";
        assertEquals(expected, genre.toString());
    }

    @Test
    public void testToStringGenres_4() {
        Genres genre = new Genres(4, "Horror");
        String expected = "4 | Horror";
        assertEquals(expected, genre.toString());
    }

    @Test
    public void testToStringGenres_5() {
        Genres genre = new Genres(5, "Sci-Fi");
        String expected = "5 | Sci-Fi";
        assertEquals(expected, genre.toString());
    }
}