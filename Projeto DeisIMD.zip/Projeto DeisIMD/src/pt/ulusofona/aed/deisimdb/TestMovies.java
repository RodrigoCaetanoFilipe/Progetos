package pt.ulusofona.aed.deisimdb;

import org.junit.jupiter.api.Test;
import pt.ulusofona.aed.deisimdb.Movies;

import static org.junit.jupiter.api.Assertions.*;

public class TestMovies {

    @Test
    public void testToStringMoviesIdGreaterThanOrEqual1000() {
        Movies movie = new Movies(1000, "BLALALA", 120.0f, 1000000, "2023-01-01");
        String expected = "1000 | BLALALA | 01-01-2023";
        assertEquals(expected, movie.toString());
    }

    @Test
    public void testToStringMoviesIdGreaterThanOrEqual1000_2() {
        Movies movie = new Movies(1500, "AAAAAAAAA", 90.0f, 500000, "2022-05-15");
        String expected = "1500 | AAAAAAAAA | 15-05-2022";
        assertEquals(expected, movie.toString());
    }

    @Test
    public void testToStringMoviesIdGreaterThanOrEqual1000_3() {
        Movies movie = new Movies(1234, "E", 0.0f, 0, "9999-99-99");
        String expected = "1234 | E | 99-99-9999";
        assertEquals(expected, movie.toString());
    }

    @Test
    public void testToStringMoviesIdGreaterThanOrEqual1000_4() {
        Movies movie = new Movies(9999, "uM gAH mEMO", 99999.0f, 9999999, "0000-00-00");
        String expected = "9999 | uM gAH mEMO | 00-00-0000";
        assertEquals(expected, movie.toString());
    }

    @Test
    public void testToStringMoviesIdGreaterThanOrEqual1000_5() {
        Movies movie = new Movies(2006, "Nascimento de um gah memo", 69.0f, 0, "2006-11-17");
        String expected = "2006 | Nascimento de um gah memo | 17-11-2006";
        assertEquals(expected, movie.toString());
    }

}
