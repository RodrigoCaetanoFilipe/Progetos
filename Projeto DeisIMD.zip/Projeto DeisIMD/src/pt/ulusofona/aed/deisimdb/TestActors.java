package pt.ulusofona.aed.deisimdb;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestActors {

    @Test
    public void testToStringActors() {
        Actors actor = new Actors(1, "Tralalerotralalá", "M", 1000);
        String expected = "1 | Tralalerotralalá | Masculino | 1000";
        assertEquals(expected, actor.toString());
    }

    @Test
    public void testToStringActors_2() {
        Actors actor = new Actors(2, "Bombardilo Crocodilo", "M", 1500);
        String expected = "2 | Bombardilo Crocodilo | Masculino | 1500";
        assertEquals(expected, actor.toString());
    }

    @Test
    public void testToStringActors_3() {
        Actors actor = new Actors(3, "Mia K", "F", 2000);
        String expected = "3 | Mia K | Feminino | 2000";
        assertEquals(expected, actor.toString());
    }

    @Test
    public void testToStringActors_4() {
        Actors actor = new Actors(4, "Fourth Actor", "F", 2500);
        String expected = "4 | Fourth Actor | Feminino | 2500";
        assertEquals(expected, actor.toString());
    }

    @Test
    public void testToStringActors_5() {
        Actors actor = new Actors(5, "LeBron", "M", 3000);
        String expected = "5 | LeBron | Masculino | 3000";
        assertEquals(expected, actor.toString());
    }
}