package pt.ulusofona.aed.deisimdb;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestMovieVotes {

    @Test
    public void testToStringMovieVotes() {
        MovieVotes vote = new MovieVotes(1, 8.5f, 1000);
        String expected = "1 | 8.5 | 1000";
        assertEquals(expected, vote.toString());
    }

    @Test
    public void testToStringMovieVotes_2() {
        MovieVotes vote = new MovieVotes(2, 7.0f, 1500);
        String expected = "2 | 7.0 | 1500";
        assertEquals(expected, vote.toString());
    }

    @Test
    public void testToStringMovieVotes_3() {
        MovieVotes vote = new MovieVotes(3, 9.0f, 2000);
        String expected = "3 | 9.0 | 2000";
        assertEquals(expected, vote.toString());
    }

    @Test
    public void testToStringMovieVotes_4() {
        MovieVotes vote = new MovieVotes(4, 6.5f, 2500);
        String expected = "4 | 6.5 | 2500";
        assertEquals(expected, vote.toString());
    }

    @Test
    public void testToStringMovieVotes_5() {
        MovieVotes vote = new MovieVotes(5, 5.0f, 3000);
        String expected = "5 | 5.0 | 3000";
        assertEquals(expected, vote.toString());
    }
}