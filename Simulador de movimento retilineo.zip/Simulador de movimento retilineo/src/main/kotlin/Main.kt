import kotlin.math.*

fun validarEntrada(variavel: String, valor: Float?): Boolean {
    if (valor == null) {
        println("Insira um valor numérico válido.")
        return false
    }
    if (valor < 0) {
        println("Insira um valor positivo para $variavel.")
        return false
    }
    return true
}

fun inserirDadosAmbiente(): Triple<Float, Float, Float> {
    var altmuro: Float
    var distmuro: Float
    var alt: Float

    while (true) {
        println("Insira a altura do muro:")
        altmuro = readLine()!!.toFloatOrNull() ?: continue
        if (validarEntrada("altura do muro", altmuro)) break
    }

    while (true) {
        println("Insira a distância em relação ao muro:")
        distmuro = readLine()!!.toFloatOrNull() ?: continue
        if (validarEntrada("distância até o muro", distmuro)) break
    }

    while (true) {
        println("Insira a altura de lançamento do objeto:")
        alt = readLine()!!.toFloatOrNull() ?: continue
        if (validarEntrada("altura de lançamento", alt)) break
    }

    return Triple(altmuro, distmuro, alt)
}

fun inserirDadosLancamento(): Pair<Float?,Float?>{
    var angulo: Float? = null
    var v0: Float? = null

    while (angulo == null && v0 == null) {
        println("Insira o ângulo de lançamento (ou pressione enter para ignorar):" )
        angulo = readLine()!!.toFloatOrNull()

        println("Insira a velocidade inicial (ou pressione enter para ignorar):")
        v0 = readLine()!!.toFloatOrNull()

        if (angulo == null && v0 == null) {
            println("É necessário informar pelo menos um dos dados.")
        }
    }
    return Pair(angulo, v0)
}

fun calculoTempoDeVoo(v0: Float, angulo:Float, alt: Float):Triple<Float?,Float?,Float?>{
    val altMax = alt +((v0 * sin(angulo).pow(2))/(2 * 9.8)).toFloat()
    val tempoDeVoo = (((v0 * sin(angulo)) + sqrt(v0.pow(2) * sin(angulo).pow(2) -(2 * 9.8 * alt)))/9.8).toFloat()
    val tempoDeSubida = ((v0 * sin(angulo))/ 9.8).toFloat()
    return Triple(altMax,tempoDeSubida,tempoDeVoo)
}

fun desenharTrajetoria(grafico: Chart, velocidadeX: Double, velocidadeY: Double,colidiu:Int,distmuro:Float, legenda: String) {
    grafico.reset()

    var tempo = 0.0
    val intervaloTempo = 0.0001
    var ativo = true
    while (ativo) {
        val x = velocidadeX * tempo
        val y = velocidadeY * tempo - 0.5 * 10.0 * tempo * tempo
        grafico.ponto(x, y)
        tempo += intervaloTempo
        if(colidiu == 1){if(x>distmuro){ativo=false}}
        if (y < 0){ativo = false}
    }
    println("Trajetória para $legenda:")
    grafico.draw()
}
fun alturaTempo(grafico: Chart,v0: Float,angulo: Float,distmuro: Float,colidiu:Int,legenda: String){
    grafico.reset()

    val tempoChoque = distmuro/(v0 * cos(angulo))
    val v0y = v0 * sin(angulo)
    var tempo = 0.0
    val intervaloTempo = 0.0001
    var ativo = true
    while (ativo) {
        val y = v0y * tempo - 0.5 * 10.0 * tempo * tempo
        grafico.ponto(tempo, y)
        tempo += intervaloTempo
        if (colidiu==1){if (tempo>tempoChoque){ativo = false}}
        if (y < 0){ativo = false}
    }
    println("Trajetória para $legenda:")
    grafico.draw()
}
fun calculoDeDadosLacamento(v0: Float?,angulo: Float?, alt: Float,distmuro:Float,altmuro: Float):Array<Float>{
    val output = arrayOf(0f,0f)
    val g = 9.8f
    if (angulo != null){
        if (v0 == null){
            output[0] = sqrt(((2 * g * distmuro.pow(2)) / ((distmuro * tan(angulo) - (altmuro + 0.001 - alt)) * cos(angulo).pow(2))).toFloat())
            output[1] = 1f
        }
    }else {
        if (v0 != null) {
            output[0] = atan((alt + ((9.8 * distmuro.pow(2)) / (2 * v0.pow(2))) / distmuro)).toFloat()
            output[1] = 2f
        }
    }
    return output
}
fun colisao(v0: Float,angulo: Float, altmuro: Float,distmuro:Float): Int{
    val g = 9.8
    val altura = distmuro * tan(angulo) - ((g* distmuro.pow(2))/(2* v0.pow(2) * cos(angulo).pow(2)) )
    return if(altura < altmuro){
        1
    }else{
        0
    }

}

fun main() {
    val larguraGrafivo = 200
    val alturaGrafico = 40
    val grafico = Chart(larguraGrafivo,alturaGrafico)

    var simulador = true
    var altmuro: Float? = null
    var distmuro: Float? = null
    var alt: Float? = null
    var angulo : Float? = null
    var v0 : Float? = null
    var altMax: Float?
    var tempoDeDescida: Float?
    var tempoDeSubida: Float?
    var tempoDeVoo: Float? = null
    var validocolisao=false


    println("\nSimulador de Movimento Curvilíneo")
    println("by Rodrigo Caetano Filipe, Alexandre Chen e Felipe Machado\n")

    while (simulador) {
        println("Selecione a opção:")
        println("1 - Inserir dados do ambiente")
        println("2 - Inserir dados do lançamento")
        println("3 - Mostrar dados")
        println("4 - Graficos")
        println("0 - Desligar o simulador")

        val opcao = readLine()!!.toIntOrNull()
        when (opcao) {
            1 -> {
                val dadosAmbiente = inserirDadosAmbiente()
                altmuro = dadosAmbiente.first
                distmuro = dadosAmbiente.second
                alt = dadosAmbiente.third
            }
            2 -> {
                if (altmuro==null){
                    println("insira primeiro os dados do ambiente")
                }else{
                    val dadosLancamento = inserirDadosLancamento()
                    angulo = dadosLancamento.first
                    v0 = dadosLancamento.second
                    if (angulo == null && v0 != null || angulo != null && v0 == null){
                        val calculoDeDadosLacamento = calculoDeDadosLacamento(v0,angulo,alt!!,distmuro!!,altmuro)
                        when(calculoDeDadosLacamento[1]){
                            1f -> v0 = calculoDeDadosLacamento[0]
                            2f -> angulo = calculoDeDadosLacamento[0]
                        }

                    }
                }
                validocolisao=true
            }

            3 -> {
                println("Dados do ambiente:")
                if (altmuro == null){
                    println("-Altura do muro: indefenido")
                }
                else{
                    println("-Altura do muro: $altmuro metros")
                }
                if (distmuro == null){
                    println("-Distância até o muro: indefenido")
                }
                else{
                    println("-Distância até o muro: $distmuro metros")
                }
                if(alt == null){
                    println("-Altura de lançamento:indefenido")
                }
                else{
                    println("-Altura de lançamento: $alt metros")
                }
                println()
                println("Dados do lançamento")
                if(angulo== null){
                    println("-Angulo de lançamento: indefenido")
                }
                else{
                    println("-Angulo de lançamento:$angulo graus")
                }
                if(v0 == null){
                    println("-Velocidade inicial: indefenido")
                }
                else{
                    println("-Velocidade inicial:$v0 m/s ")
                }
                println()
                println("Outros dados")
                println("-Gravidade : 9.8 m/s2")
                if (v0 != null) {
                    val caluloTempoDeVoo = calculoTempoDeVoo(v0, angulo!!, alt!!)
                    altMax = caluloTempoDeVoo.first
                    tempoDeSubida = caluloTempoDeVoo.second
                    tempoDeVoo = caluloTempoDeVoo.third

                    if (altMax == null) {
                        println("-Altura maxima: indefenido")
                    } else {
                        println("-Altura maxima:$altMax metros")
                    }
                    if (tempoDeVoo == null && tempoDeSubida == null) {
                        println("-Tempo de descida: indefenido")
                    } else {
                    if (tempoDeVoo != null && tempoDeSubida!= null){
                        val tempoDeDescida= tempoDeVoo - tempoDeSubida
                        println("-Tempo de descida:$tempoDeDescida segundos")
                        }
                    }
                    if (tempoDeSubida == null) {
                        println("-Tempo de subida: indefenido")
                    } else {
                        println("-Tempo de subida:$tempoDeSubida segundos")
                    }
                    if (tempoDeVoo == null) {
                        println("-Tempo de voo: indefenido")
                    } else {
                        println("-Tempo de voo:$tempoDeVoo segundos")
                    }
                    if (!validocolisao){
                        println("- O progetil colide com a parede: indefenido")
                    }else{
                        val colidiu = colisao(v0,angulo,altmuro!!,distmuro!!)
                        if (colidiu == 1){
                            println("- O progetil colide com a parede: Sim")

                        }else{
                            println("- O progetil colide com a parede: Não")
                        }
                    }
                }

            }
            4 -> {
                if (v0 == null || angulo == null){
                    println("Insira todos os dados antes de desenhar os graficos")
                }else {
                    val colidiu = colisao(v0,angulo,altmuro!!,distmuro!!)
                    var valido = false
                    while (!valido) {
                    println("1 - Grafico de X em relação ao Y")
                    println("2 - Grafico de Y em relação ao tempo")
                    val opcaoGrafico = readLine()!!.toIntOrNull()
                    val v0x = v0 * cos(angulo).toDouble()
                    val v0y = v0 * sin(angulo).toDouble()

                        when (opcaoGrafico) {
                            1 -> {
                                desenharTrajetoria(grafico, v0x, v0y, colidiu, distmuro, "Grafico de X em relação ao Y")
                                valido = true
                            }

                            2 -> {
                                alturaTempo(grafico, v0, angulo, distmuro, colidiu, "Grafico de Y em relação ao tempo")
                                valido = true
                            }

                            else -> println("opção invalida")
                        }
                    }
                }
            }
            0 -> {
                println("Obrigado por usar o simulador! Encerrando...")
                simulador = false
            }
            else -> {
                println("Opção inválida. Tente novamente.")
            }
        }
    }
}
