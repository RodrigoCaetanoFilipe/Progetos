package pt.ulusofona.aed.deisimdb;

public class GenreMovies {
    int genreId;
    int movieId;
    public GenreMovies(int genreId, int movieId){
        this.genreId = genreId;
        this.movieId = movieId;
    }
    @Override
    public String toString() {
        String texto = genreId + " | " + movieId;
        return texto;
    }
}
