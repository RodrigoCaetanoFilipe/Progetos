package pt.ulusofona.aed.deisimdb;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;



public class Main {
    static String[] ficheros = {"movies.csv", "actors.csv", "directors.csv", "genres.csv"
            , "genre_movies.csv", "movie_votes.csv"};

    static ArrayList<Movies> movies = new ArrayList<>();
    static ArrayList<Actors> actors = new ArrayList<>();
    static ArrayList<Directors> directors = new ArrayList<>();
    static ArrayList<Genres> genres = new ArrayList<>();
    static ArrayList<GenreMovies> genreMovies = new ArrayList<>();
    static ArrayList<MovieVotes> movieVotes = new ArrayList<>();
    static ArrayList<InputInvalido> inputInvalidos = new ArrayList<>();

    public static int contarAtoresPorFilmeId(int id) {

        int contador = 0;
        for (Actors actor : actors) {
            if (actor.movieId == id) {
                contador++;
            }
        }
        return contador;
    }

    public static boolean parseFiles(File files) {
        movies.clear();
        actors.clear();
        directors.clear();
        genres.clear();
        genreMovies.clear();
        movieVotes.clear();
        inputInvalidos.clear();

        //verifica se o ficheiro existe
        if (!files.isDirectory()) {
            System.out.println("O Diretorio não existe");
            return false;
        }
        //cria os ficheiros
        File file1 = new File(files, "movies.csv");
        File file2 = new File(files, "actors.csv");
        File file3 = new File(files, "directors.csv");
        File file4 = new File(files, "genres.csv");
        File file5 = new File(files, "genres_movies.csv");
        File file6 = new File(files, "movie_votes.csv");

        //verifica se os ficheiros existem
        if (!file1.exists()) {
            System.out.println("O ficheiro movies.csv não existe");
            return false;
        }
        if (!file2.exists()) {
            System.out.println("O ficheiro actors.csv não existe");
            return false;
        }
        if (!file3.exists()) {
            System.out.println("O ficheiro directors.csv não existe");
            return false;
        }
        if (!file4.exists()) {
            System.out.println("O ficheiro genres.csv não existe");
            return false;
        }
        if (!file5.exists()) {
            System.out.println("O ficheiro genre_movies.csv não existe");
            return false;
        }
        if (!file6.exists()) {
            System.out.println("O ficheiro movie_votes.csv não existe");
            return false;
        }

        //verifica se os ficheiros estão vazios
        if (file1.length() == 0) {
            System.out.println("O ficheiro movies.csv está vazio");
            return false;
        }
        if (file2.length() == 0) {
            System.out.println("O ficheiro actors.csv está vazio");
            return false;
        }
        if (file3.length() == 0) {
            System.out.println("O ficheiro directors.csv está vazio");
            return false;
        }
        if (file4.length() == 0) {
            System.out.println("O ficheiro genres.csv está vazio");
            return false;
        }
        if (file5.length() == 0) {
            System.out.println("O ficheiro genre_movies.csv está vazio");
            return false;
        }
        if (file6.length() == 0) {
            System.out.println("O ficheiro movie_votes.csv está vazio");
            return false;
        }


        //preenche as classes
        for (int i = 0; i < ficheros.length; i++) {
            boolean cabecalho = true;
            boolean primeiraInvalida = true;
            int linhasValidas = 0;
            int linhasInvalidas = 0;
            int primeiroErro = -1;

            switch (ficheros[i]){
                case "actors.csv" -> {
                    try {
                        Scanner leitorActors = new Scanner(file2);

                        for (int e = 0; leitorActors.hasNextLine(); e++) {
                            String linha = leitorActors.nextLine();
                            String[] campo = linha.split(",");
                            if (!cabecalho) {
                                // verifica se existe um campo a mais
                                if (campo.length != 4 || campo[0].isEmpty() || campo[1].isEmpty()
                                        || campo[2].isEmpty() || campo[3].isEmpty()
                                        || Utils.intOrNull(campo[0].trim()) == null
                                        || Utils.intOrNull(campo[3].trim()) == null) {
                                    if (primeiraInvalida) {
                                        primeiroErro = e;
                                        primeiraInvalida = false;
                                    }
                                    linhasInvalidas++;
                                } else {
                                    linhasValidas++;
                                    int id = Integer.parseInt(campo[0]);
                                    String nome = campo[1];
                                    String genero = campo[2];
                                    int idFilme = Integer.parseInt(campo[3]);

                                    actors.add(new Actors(id, nome, genero, idFilme));
                                }
                            }
                            if(cabecalho) {
                                cabecalho = false;
                            }
                        }

                        inputInvalidos.add(new InputInvalido("actors.csv", linhasValidas, linhasInvalidas, primeiroErro));
                        leitorActors.close();

                    } catch (Exception e) {
                        System.out.println("Erro ao abrir o ficheiro actors.csv");
                        return false;
                    }
                }
                case "movies.csv" -> {
                    try {
                        Scanner leitorMovies = new Scanner(file1);

                        for (int e = 0; leitorMovies.hasNextLine(); e++) {
                            String linha = leitorMovies.nextLine();
                            String[] campo = linha.split(",");
                            if (!cabecalho) {
                                // verifica se existe um campo a mais
                                if (campo.length != 5
                                        || campo[0].isEmpty() || campo[1].isEmpty()
                                        || campo[2].isEmpty() || campo[3].isEmpty() || campo[4].isEmpty()
                                        ||Utils.intOrNull(campo[3].trim()) == null
                                        || Utils.floatOrNull(campo[2].trim()) == null) {
                                    if (primeiraInvalida) {
                                        primeiroErro = e;
                                        primeiraInvalida = false;
                                    }
                                    linhasInvalidas++;

                                } else {
                                    linhasValidas++;
                                    int id = Integer.parseInt(campo[0]);
                                    String nome = campo[1];
                                    float duracao = Float.parseFloat(campo[2].trim());
                                    int orcamento = Integer.parseInt(campo[3].trim());
                                    String data = campo[4];
                                    int numAtores = 0;
                                    if (id < 1000){
                                        numAtores = contarAtoresPorFilmeId(id);
                                    }

                                    movies.add(new Movies(id, nome, duracao, orcamento, data));
                                }
                            }
                            if(cabecalho) {
                                cabecalho = false;
                            }
                        }

                        inputInvalidos.add(new InputInvalido("movies.csv", linhasValidas, linhasInvalidas, primeiroErro));
                        leitorMovies.close();

                    } catch (Exception e) {
                        System.out.println("Erro ao abrir o ficheiro movies.csv") ;
                        return false;
                    }

                }
                case "directors.csv" -> {
                    try {
                        Scanner leitorDirectors = new Scanner(file3);

                        for (int e = 0; leitorDirectors.hasNextLine(); e++){
                            String linha = leitorDirectors.nextLine();
                            String[] campo = linha.split(",");

                            if (!cabecalho) {
                                // verifica se existe um campo a mais
                                if (campo.length != 3 || campo[0].isEmpty() || campo[1].isEmpty() || campo[2].isEmpty()
                                        || Utils.intOrNull(campo[0].trim()) == null
                                        || Utils.intOrNull(campo[2].trim()) == null) {
                                    if (primeiraInvalida) {
                                        primeiroErro = e;
                                        primeiraInvalida = false;
                                    }
                                    linhasInvalidas++;
                                } else {
                                    linhasValidas++;
                                    int id = Integer.parseInt(campo[0]);
                                    String nome = campo[1];
                                    int idFilme = Integer.parseInt(campo[2]);

                                    directors.add(new Directors(id, nome, idFilme));
                                }
                            }
                            if(cabecalho) {
                                cabecalho = false;
                            }
                        }

                        inputInvalidos.add(new InputInvalido("directors.csv",linhasValidas,linhasInvalidas,primeiroErro));

                        leitorDirectors.close();
                    } catch (Exception e) {
                        System.out.println("Erro ao abrir o ficheiro directors.csv");
                        return false;
                    }
                }

                case "genres.csv" -> {
                    try {
                        Scanner leitorGenres = new Scanner(file4);

                        for (int e = 0; leitorGenres.hasNextLine(); e++){
                            String linha = leitorGenres.nextLine();
                            String[] campo = linha.split(",");

                            if (!cabecalho) {
                                // verifica se existe um campo a mais
                                if (campo.length != 2 || campo[0].isEmpty() || campo[1].isEmpty()
                                    || Utils.intOrNull(campo[0].trim()) == null) {
                                    if (primeiraInvalida) {
                                        primeiroErro = e;
                                        primeiraInvalida = false;
                                    }
                                    linhasInvalidas++;
                                } else {
                                    linhasValidas++;

                                    int id = Integer.parseInt(campo[0]);
                                    String nome = campo[1].trim();

                                    genres.add(new Genres(id, nome));
                                }
                            }
                            if(cabecalho) {
                                cabecalho = false;
                            }
                        }

                        inputInvalidos.add(new InputInvalido("genres.csv",linhasValidas,linhasInvalidas,primeiroErro));

                        leitorGenres.close();
                    } catch (Exception e) {
                        System.out.println("Erro ao abrir o ficheiro genres.csv"+ e.getMessage() );
                        return false;
                    }
                }
                case "genre_movies.csv" -> {
                    try {
                        Scanner leitorGenreMovies = new Scanner(file5);

                        for (int e = 0; leitorGenreMovies.hasNextLine(); e++){
                            String linha = leitorGenreMovies.nextLine();
                            String[] campo = linha.split(",");

                            if (!cabecalho) {
                                // verifica se existe um campo a mais
                                if (campo.length != 2 || campo[0].isEmpty() || campo[1].isEmpty()
                                        || Utils.intOrNull(campo[0].trim()) == null
                                        || Utils.intOrNull(campo[1].trim()) == null){
                                    if (primeiraInvalida) {
                                        primeiroErro = e;
                                        primeiraInvalida = false;
                                    }
                                    linhasInvalidas++;
                                } else {
                                    linhasValidas++;
                                    int idFilme = Integer.parseInt(campo[0]);
                                    int idGenero = Integer.parseInt(campo[1].trim());

                                    genreMovies.add(new GenreMovies(idFilme, idGenero));
                                }
                            }
                            if(cabecalho) {
                                cabecalho = false;
                            }
                        }

                        inputInvalidos.add(new InputInvalido("genres_movies.csv",linhasValidas,linhasInvalidas,primeiroErro));

                        leitorGenreMovies.close();
                    } catch (Exception e) {
                        System.out.println("Erro ao abrir o ficheiro genre_movies.csv");
                        return false;
                    }
                }
                case "movie_votes.csv" -> {
                    try {
                        Scanner leitorMovieVotes = new Scanner(file6);

                        for (int e = 0; leitorMovieVotes.hasNextLine(); e++){
                            String linha = leitorMovieVotes.nextLine();
                            String[] campo = linha.split(",");

                            if (!cabecalho) {
                                // verifica se existe um campo a mais
                                if (campo.length != 3 || campo[0].isEmpty() || campo[1].isEmpty() || campo[2].isEmpty()
                                        || Utils.intOrNull(campo[0].trim()) == null
                                        || Utils.floatOrNull(campo[1].trim()) == null
                                        || Utils.intOrNull(campo[2].trim()) == null) {
                                    if (primeiraInvalida) {
                                        primeiroErro = e;
                                        primeiraInvalida = false;
                                    }
                                    linhasInvalidas++;
                                } else {
                                    linhasValidas++;
                                    int idFilme = Integer.parseInt(campo[0]);
                                    float rating = Float.parseFloat(campo[1]);
                                    int numVotos = Integer.parseInt(campo[2]);

                                    movieVotes.add(new MovieVotes(idFilme, rating, numVotos));
                                }
                            }
                            if(cabecalho) {
                                cabecalho = false;
                            }
                        }

                        inputInvalidos.add(new InputInvalido("movie_votes.csv",linhasValidas,linhasInvalidas,primeiroErro));

                        leitorMovieVotes.close();
                    } catch (Exception e) {
                        System.out.println("Erro ao abrir o ficheiro movie_votes.csv");
                        return false;
                    }
                }
            }
        }
        return true;
    }
    public static ArrayList getObjects(TipoEntidade tipo){
        switch (tipo) {
            case ATOR:
                return actors;
            case REALIZADOR:
                return directors;
            case GENERO_CINEMATOGRAFICO:
                return genres;
            case FILME:
                return movies;
            case INPUT_INVALIDO:
                return inputInvalidos;
            default:
                throw new IllegalArgumentException("Tipo de entidade desconhecido: " + tipo);
        }
    }


        public static void main (String[]args){

            System.out.println("Bem-vindo ao deisIMDB");

            long start = System.currentTimeMillis();
            boolean parseOK = parseFiles(new File("."));
            if (!parseOK) {
                System.out.println("Erro na leitura dos ficheiros");
                return;
            }
            long end = System.currentTimeMillis();
            System.out.println("Ficheiros lidos com sucesso em " + (end - start) + " ms");


        ArrayList filmes = getObjects(TipoEntidade.FILME);
        System.out.println(filmes.get(0));
        System.out.println(filmes.get(1));
        System.out.println(filmes.get(2));
        System.out.println(filmes.get(3));
        System.out.println(filmes.get(4));
        System.out.println(filmes.get(5));
        System.out.println(filmes.get(6));
        System.out.println(filmes.get(7));
        System.out.println(filmes.get(8));

        }
}
