package pt.ulusofona.aed.deisimdb;

public class MovieVotes {
    int movieId;
    float movieRating;
    int movieRatingCount;
    public MovieVotes(int movieId, float movieRating, int movieRatingCount){
        this.movieId = movieId;
        this.movieRating = movieRating;
        this.movieRatingCount = movieRatingCount;
    }
    @Override
    public String toString() {
        String texto = movieId + " | " + movieRating + " | " + movieRatingCount;
        return texto;
    }
}

